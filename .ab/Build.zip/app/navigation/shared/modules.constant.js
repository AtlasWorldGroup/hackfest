"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/// modules imports
var pushView_module_1 = require("../../modules/pushView/pushView.module");
var homeView_module_1 = require("../../modules/homeView/homeView.module");
exports.MODULES = [
    /// start modules declaration
    pushView_module_1.PushViewModule,
    homeView_module_1.HomeViewModule
    /// end modules declaration
];
