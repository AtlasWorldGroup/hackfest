"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var HomeViewService = (function () {
    function HomeViewService() {
    }
    return HomeViewService;
}());
HomeViewService = __decorate([
    core_1.Injectable()
], HomeViewService);
exports.HomeViewService = HomeViewService;
