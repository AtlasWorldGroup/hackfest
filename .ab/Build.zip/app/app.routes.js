"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.appRoutes = [
    {
        path: "",
        redirectTo: "/nav",
        pathMatch: "full"
    }
];
